﻿using System;

namespace CRUDMVCWebApplication.Models
{
    public class Employee
    {
        public int Id;
        public string FirstName;
        public string LastName;
        public string EmailId;
        public long PhoneNumber;
        public string Address;
        public string Department;

        public Employee GetRandomEmployee()// what will happen if we remove this class??
        {
            Employee emp = new Employee();
            int randnum = new Random().Next(1, 99);
            //Console.WriteLine("Please First Name", emp.FirstName);
            //string Firstname = Console.ReadLine();
            //emp.FirstName = FirstName.ToString();
            //emp.LastName = LastName.ToString();
            //emp.EmailId = EmailId;
            //emp.PhoneNumber = PhoneNumber;
            //emp.Address = Address;
            //emp.Department = Department;
            //emp.FirstName = "Employee " + randnum.ToString();
            emp.FirstName = FirstName + randnum.ToString();
            emp.LastName = "LastName " + randnum.ToString();
            emp.EmailId = "CHB3324 " + randnum.ToString() + "@gmail.com";
            emp.PhoneNumber = 6174567890;
            emp.Address = "MA, USA " + randnum.ToString();
            emp.Department = "Department " + randnum.ToString();

            return emp;
        }
    }
}
